import pandas as pd
lat = 12323
log = 4898
latlong=pd.DataFrame({'latitude':lat,'longitude':log})
print(latlong)